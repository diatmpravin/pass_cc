$: << File.dirname(__FILE__)
require 'app42/command/client'

module App42

  #def app42(*comm )
  #  action = comm.shift.strip rescue 'help'
  #  App42::Client.start(action, comm)
  #end

end
