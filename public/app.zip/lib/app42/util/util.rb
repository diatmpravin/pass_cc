require 'base64'
require 'cgi'
require 'hmac-sha1'

module App42
  class Util

    def get_timestamp_utc
      Time.now.utc.strftime("%Y-%m-%dT%H:%M:%S.%LZ")
    end

    def sign secret_key, params
      sorted_params =  sort_convert_table(params)
      puts sorted_params
      signature = compute_hmac(secret_key, sorted_params)
      puts "Signature #{signature}"
      signature
    end

    def sort_convert_table(table)
      sorted_params = ""
      table.sort {|a,b| a[0] <=> b[0]}.each{ |key, val|
        sorted_params << key
        sorted_params << val
      }
      puts "Sorted params #{sorted_params}"
      sorted_params
    end

    def compute_hmac(secret_key, sorted_params)
      signature =  Base64.encode64(HMAC::SHA1::digest(secret_key, sorted_params)).strip
      puts "Signature #{signature}"
      computed_hmac = CGI.escape(signature)
      puts "Computed Hmac #{computed_hmac}"
      computed_hmac
    end

  end
end