require "rest-client"
require 'uri'

module App42
  class App42RestClient
    attr_accessor :host

    def initialize(host= HOST)
      puts "RESTConnection->initialize"
      puts "Base url 0 #{host}"
      @host = host
    end

    def authentication resource_url, query_params
      resource = ""
      resource << @host << resource_url
      print Paint["Authenticating...", :yellow]
      response = RestClient.post resource, :accept => JSON_MIME_TYPE, :content_type => JSON_MIME_TYPE, :params => query_params
      puts Paint["#{response.code}", :cyan]
      json_res = JSON.parse(response) unless response.nil?
      return json_res
    end

    #def post signature, resource_url, query_params, body
    #  puts 'In rest_client post--------------------------!!'
    #  resource = ""
    #  resource << HOST << resource_url
    #  response = RestClient.post resource, body , :accept => JSON_MIME_TYPE, :content_type => JSON_MIME_TYPE, :params => query_params
    #  return {"domain" => 'http://demoapp43.app42.com', "cdn_url" => 'www-origin.nixcraft.in'}
    #end
    #
    #def multipart signature, resource_url, query_params, body, source_path
    #  puts 'In rest_client Multipart--------------------------!!'
    #  resource = ""
    #  resource << HOST << resource_url
    #  response = RestClient.post( resource,
    #    {
    #        :source_zip => File.open(source_path, "rb"),
    #        :name => 'test',
    #        :type => 'zip'
    #    },
    #    :accept => JSON_MIME_TYPE,
    #    :content_type => JSON_MIME_TYPE,
    #    :params => query_params
    #  )
    #  json_res = JSON.parse(response) unless response.nil?
    #  return json_res
    #end
    #
    #def get signature, resource_url, query_params
    #  p  signature
    #  p resource_url
    #  p query_params
    #  puts 'In rest_client get--------------------------!!'
    #end


    def get(signature, url, params)
      params.store("signature", signature)
      resource = ""
      resource << @host << url
      resource = URI.escape(resource).gsub("+", "%20")
      begin
        response = RestClient.get resource,:accept => JSON_MIME_TYPE, :content_type => JSON_MIME_TYPE, :params => params
        puts response.headers
        puts response.body
      rescue => e
        puts e
      end
      return response
    end

    def post(signature, url, params, body)
      params.store("signature", signature)
      resource = ""
      resource << @host << url
      resource = URI.escape(resource).gsub("+", "%20")
      begin
        response = RestClient.post resource, body, :accept => JSON_MIME_TYPE, :content_type => JSON_MIME_TYPE, :params => params
        puts Paint["#{response.code}", :cyan]
      rescue => e
        puts e
      end
      return response
    end

    def put(signature, url, params, body)
      params.store("signature", signature)
      resource = ""
      resource << @host << url
      resource = URI.escape(resource).gsub("+", "%20")
      begin
        response = RestClient.put resource, body,:accept => 'application/json', :content_type => 'application/json', :params => params
        puts response.code
        puts response.to_str
      rescue => e
        puts e
      end
      return response
    end

    def delete(signature, url, params)
      params.store("signature", signature)
      resource = ""
      resource << @host << url
      resource = URI.escape(resource).gsub("+", "%20")
      begin
        response = RestClient.delete resource, :accept => 'application/json', :content_type => 'application/json', :params => params
        puts response.code
        puts response.to_str
      rescue => e
        puts e
      end
      return response
    end

    def multipart(signature, url, params, post_params, source_path)
      params.store("signature", signature)
      resource = ""
      resource << @host << url
      resource = URI.escape(resource).gsub("+", "%20")

      begin
        # TODO, should be dynamic for multiple calls
        response = RestClient.post( resource,
          {
              :source_zip => File.open(source_path, "rb"),
              :name => 'test',
              :type => 'zip'
          },
          :accept => JSON_MIME_TYPE,
          :content_type => JSON_MIME_TYPE,
          :params => post_params
        )
        puts Paint["#{response.code}", :cyan]
      rescue => e
        puts e
      end
      return response
    end

  end
end