module App42
  class Version
    def version
      "0.0.1".freeze
    end
  end
end
