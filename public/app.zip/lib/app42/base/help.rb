require 'paint'

module App42
  class Help

    def self.how_to
      Paint["Usage: app42 COMMAND [--app APP] [command-specific-options]\n", :blue]
    end

    def self.commands

      <<-USAGE

#{how_to}

Primary help topics, type "app42 help TOPIC" for more details:

  apps      #  manage apps (create, destroy)
  config    #  manage app config vars
  domains   #  manage custom domains
  logs      #  display logs for an app
  releases  #  manage app releases
  login     #  login using command line

Additional topics:

  account      #  manage app42 account options
  help         #  display help
  list         #  list commands
  keys         #  manage authentication keys
  maintenance  #  manage maintenance mode for an app
  zone         #  list available zones
  status       #  check status of app42 platform
  update       #  update the app42 client
  version      #  display version

      USAGE
    end
  end
end
