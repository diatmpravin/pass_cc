module App42
  HOST = 'http://localhost:3000'

  CONFIG_DIR = "~/.app42".freeze

  LOGS_DIR = "#{CONFIG_DIR}/logs".freeze
  TARGET_FILE = "#{CONFIG_DIR}/app42_target.yml".freeze
  TOKENS_FILE = "#{CONFIG_DIR}/app42pass.yml".freeze
  CRASH_FILE = "#{CONFIG_DIR}/crash".freeze
  APP_ZIP = "#{CONFIG_DIR}/app42pass".freeze
  APP_ZIP_PATH = "#{CONFIG_DIR}/app.zip".freeze

  INFRA = ["AWS US Est" "AWS US Wst" "Netmagic"]

  JSON_MIME_TYPE = "application/json"
  XML_MIME_TYPE = "application/xml"

end