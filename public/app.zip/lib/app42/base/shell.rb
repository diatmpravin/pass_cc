module App42
  module Shell
    extend self

    APP42_COMMAND = [
      'version',
      'list',
      'login',
      'logout',
      'apps',
      'deploy'
    ]

    APP42_APP = [
      'STOPPED',
      'STARTING',
      'RUNNING',
      'STOPPING'
    ]

  end
end