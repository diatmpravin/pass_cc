require 'os'

module App42
  class Helper
    def platfrom
      OS.windows? ? windows : other
    end

    def windows
      return 'windows'
    end

    def other
      return 'linux'
    end

    def home_directory
      if platform == 'linux'

      else

      end

    end

  end
end