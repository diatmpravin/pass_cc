module App42
  class Auth
    class << self

      def logged_in?
        App42::Target.check_token_file
      end

      def check_login_status
        raise AuthError unless @user || logged_in?
      end
    end

  end
end