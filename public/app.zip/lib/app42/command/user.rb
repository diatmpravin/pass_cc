
require 'app42/command/auth'
require 'app42/command/target'
require 'app42/base/constants'
require 'app42/client/app42_rest_client'
require 'highline/import'
require "interact"
require 'paint'
require 'json/pure'
require 'fileutils'
require 'app42/email/email_validate'

module App42
  class User


    def initialize(api_key= nil, secret_key =nil , host = HOST)
      @api_key = api_key
      @secret_key = secret_key
      @resource = "user"
      @host = host
    end


    def login
      return print Paint['You are already logged in.', :red] if App42::Auth.logged_in?
      email, password = collect_login_credentials
      response, usr = nil
      usr, util  = User.new, Util.new
      begin
        connection = App42::App42RestClient.new
        query_params = {}
        body = {
            "email" => email,
            "password" => password,
            "host" => @host
        }.to_json
        query_params = body.clone
        resource_url = "/user/login"
        response = connection.authentication(resource_url, query_params)
        print Paint['Authentication successful.', :green]
      rescue  Exception => e
        puts e
      end

      #return print Paint['You are already logged in.', :red] if App42::Auth.logged_in?
      #email, password = collect_login_credentials
      #if !password.empty?
      #  query_params = {}
      #  body = {
      #      "email" => email,
      #      "password" => password,
      #      "host" => HOST
      #  }.to_json
      #  query_params = body.clone
      #  resource_url = "/user/login"
      #
      #  login_res = @@rest_client.authentication(resource_url, query_params)
      #
      result, api_key, secrete_key =  true , response['rest_client']['api_key'], response['rest_client']['secret'] unless response.nil?
      if result && api_key && secrete_key

        # TODO, NEED TO OPTIMIZE
        #App42::Target.ensure_config_dir
        #App42::Target.local_app42_target
        #App42::Target.local_app42_token api_key, secrete_key

        App42::Target.ensure_config_dir

        begin
          target_file = File.expand_path(App42::TARGET_FILE)
          FileUtils.mkdir_p(File.dirname(target_file))

          File.open(target_file, "w") do |f|
            f.puts "target:"
            f.puts "  #{HOST}"
          end
        rescue Exception => e
          puts e
        end

        begin
          token_file = File.expand_path(App42::TOKENS_FILE)
          FileUtils.mkdir_p(File.dirname(token_file))

          File.open(token_file, "w") do |f|
            f.puts "api_key:"
            f.puts "  #{api_key}"
            f.puts "secrete_key:"
            f.puts "  #{secrete_key}"
          end
        rescue Exception => e
          puts e
        end

      end
    end

    def logout
      App42::Auth.logged_in? ?
          begin
            token_file = App42::Target.remove_token_file
            Paint['Local credentials cleared.', :green]
          rescue
            Paint['Some thing went wrong.', :red]
          end :
          Paint['You are not logged in at all.', :red]
    end

    def collect_login_credentials
      email = get_email
      password = get_password
      return email, password
    end

    def get_email(prompt = Paint["Enter email:", :bright])
      puts Paint['Enter your App42PassS credentials.', :blue]
      email = ask(prompt) {|q| q.echo = true}
      email = EmailValidate::Email.new(email)
      if email.valid?
        email
      else
        puts Paint['Need a valid email.', :red]
        get_email
      end
    end

    def get_password(prompt = Paint["Password (typing will be hidden):", :bright])
      password = ask(prompt) {|q| q.echo = "*"}
      if password.empty?
        puts Paint['Need a password.', :red]
        get_password
      else
        password
      end
    end

  end
end