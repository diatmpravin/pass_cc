require 'app42/command/auth'
require 'app42/command/target'
require 'app42/util/util'
require "interact"
require 'fileutils'
require 'zip/zip'

module App42
  class App

    include Interactive

    def initialize
      @connection = App42::App42RestClient.new HOST
      target = App42::Target.target_info['target'][:token]
      @api_key, @secrete_key = App42::Target.get_keys if target.eql? HOST
      @host  =  HOST
      @resource = 'apps'
    end

    def apps
      target = App42::Target.target_info['target'][:token]
      api_key, secrete_key = App42::Target.get_keys if target.eql? HOST
      p api_key, secrete_key, HOST
      query_params, util, app = {}, Util.new, App.new
      params = {
          'api_key'=> api_key,
          'timeStamp' => util.get_timestamp_utc
      }
      query_params = params.clone
      params.store("email", 'test@gmail.com')
      signature = util.sign secrete_key, params
      resource_url = "/#{@resource}"
      response = @connection.get(signature, resource_url, query_params)
    end

    def deploy
      puts 'In deploy------------------------------------!!'
      if App42::Auth.logged_in?
        infra = get_infra
        vm_type = get_vm_type

        if vm_type == 'Shared' then
          app_url, cdn_url = shared infra, vm_type
        else
          dedicated
        end

        host_name = collect_vm_details app_url, cdn_url

      else
        Paint["Please login first.", :red]
      end
    end

    def shared  infra, vm_type
      puts 'In shared-------------------------------------------------------!!'
      app_name = get_app_name
      app_url = app_url_availabilities infra, vm_type, app_name
      app_source, git_url = collect_app_source app_url
      cdn_url = push_code_to_cdn infra, vm_type, app_name, app_source, git_url
      return app_url, cdn_url
    end

    def collect_vm_details app_url, cdn_url
      instance = get_instance
      framework =  get_framework
      runtime = get_runtime
      memory =  get_memory
      host_name = vm_create_request app_url, cdn_url, instance, framework, runtime, memory
      return host_name
    end

    def vm_create_request app_url, cdn_url, instance, framework, runtime, memory
      response, app = nil
      app, util = App.new, Util.new

      begin
        body = {'app42' => {"vm_request"=> {
            "app_url" => app_url,
            "cdn_url" => cdn_url,
            "instance" => instance,
            "framework" => framework,
            "runtime" => runtime,
            "memory" => memory
        }}}.to_json
        puts "Body #{body}"
        query_params = {}
        params = {
            'apiKey'=> @api_key,
            'time_stamp' => util.get_timestamp_utc,
        }
        query_params = params.clone
        params.store("body", body)
        signature = util.sign @secrete_key, params
        resource_url = "/#{@resource}"
        print Paint["Deploying source code...", :yellow]
        response = @connection.post(signature, resource_url, query_params, body)
        puts Paint["Host name is #{response}", :bright]
          # TODO, logic- if vm create will have any issues exist
      rescue  Exception => e
        puts e
      end
      return response

    end

    def app_url_availabilities infra, vm_type, app_name
      response, app = nil
      app, util = App.new, Util.new

      begin
        body = {'app42' => {"app_url"=> {
            "infra" => infra,
            "vm_type" => vm_type,
            "app_name" => app_name
        }}}.to_json
        puts "Body #{body}"
        query_params = {}
        params = {
            'apiKey'=> @api_key,
            'time_stamp' => util.get_timestamp_utc,
        }
        query_params = params.clone
        params.store("body", body)
        signature = util.sign @secrete_key, params
        resource_url = "/#{@resource}"
        print Paint["Checking app name availabilities...", :yellow]
        response = @connection.post(signature, resource_url, query_params, body)
        puts Paint["App URL is #{response}", :bright]
        # TODO, logic- if app_url exist
      rescue  Exception => e
        puts e
      end
      return response

    end

    def push_code_to_cdn infra, vm_type, app_name, app_source, source_url
      response, app = nil
      app, util = App.new, Util.new

      begin
        params, query_params, post_params = {}
        query_params = {
            'apiKey'=> @api_key,
            'time_stamp' => util.get_timestamp_utc,
        }
        params = query_params.clone
        post_params = {'app42' => {"cdn_url"=> {
            "infra" => infra,
            "vm_type" => vm_type,
            "app_name" => app_name,
            "app_source" => app_source,
            "source_url" => source_url,
            "name" => app_name,
            "type" => 'zip',
            "description" => 'zip source code'
        }}}.to_json
        signature = util.sign @secrete_key, params
        resource_url = "/#{@resource}"
        print Paint["Uploading source code...", :yellow]
        if source_url.include?('.zip')
          response = @connection.multipart(signature, resource_url, query_params, params, source_url)
        else
          response = @connection.post(signature, resource_url, query_params, params)
        end
        puts Paint["CDN url is #{response}", :bright]
        # TODO, logic- if any error
      rescue  Exception => e
        puts e
      end
      return response

    end

    def dedicated
      puts 'In dedicated-----------------------------------------------------!!'
      puts Paint['In progress', :yellow]
    end

    def collect_app_source app_url
      app_source = get_app_source

      source_url = zip_source_code if app_source == 'Current dir'
      return app_source, source_url if app_source == 'Current dir'

      source_url = collect_git_url if app_source == 'Git url'
      return app_source, source_url
    end

    def zip_source_code
      # TODO, should have proper dir(Probably app_name, May user will have multiple apps)
      #app_zip = File.expand_path(App42::APP_ZIP)
      #FileUtils.mkdir_p(File.dirname(app_zip))
      app_zip_path = File.expand_path(App42::APP_ZIP_PATH)

      begin
        Zip::ZipFile.open(app_zip_path, Zip::ZipFile::CREATE) do |zip|
          Dir["**/*"].each do |file|
            zip.add(file, file) { true }
          end
        end
      rescue Exception => e
        puts e
      end

      return app_zip_path
    end

    def collect_git_url
      get_git_url
    end

    def get_infra
      ask Paint["Select infra ?", :cyan],
          :choices => ["AWS US Est", "AWS US Wst", "Netmagic"],
          :indexed => true
    end

    def get_vm_type
      ask Paint["VM type ?", :cyan],
          :choices => ["Shared", "Dedicated"],
          :indexed => true
    end

    def get_app_name(prompt = Paint['App name ?', :cyan])
       ask(prompt) {|q| q.eacho = true}
    end

    def get_app_source
      ask Paint["Application source ?", :cyan],
         :choices => ["Current dir", "Git url"],
         :indexed => true
    end

    def get_git_url(prompt = Paint["Gil url ?", :cyan])
      ask(prompt) {|q| q.each = true}
    end

    def get_instance(prompt = Paint["Instance ?", :cyan])
      ask(prompt) {|q| q.each = true}
    end

    def get_framework
      ask Paint["Framework ?", :cyan],
          :choices => ["Rails", "Sinatra", "Grails","Other"],
          :indexed => true
    end

    def get_runtime
      ask Paint["Runtime ?", :cyan],
          :choices => ["Ruby18", "Ruby19", "Other"],
          :indexed => true
    end

    def get_memory
      ask Paint["Memory limit ?", :cyan],
          :choices => ["256MB", "512MB", "1GB", "2GB"],
          :indexed => true
    end



    private

    def create_domain( infra, vm_type, app_name, app_source, source_path)
      p 'In create domain--------------------------------------!!'
      target = App42::Target.target_info['target'][:token]
      api_key, secrete_key = App42::Target.get_keys if target.eql? HOST
      body = {'app42' => {"app"=> {
          "infra" => infra,
          "vm_type" => vm_type,
          "app_name" => app_name,
          "app_source" => app_source
      }}}.to_json
      query_params, util = {}, Util.new
      params = {
          'api_key'=> api_key,
          'timeStamp' => util.get_timestamp_utc
      }
      query_params = params.clone
      params.store("body", body)
      puts params
      puts query_params
      signature = util.sign secrete_key, params
      resource_url = "#{@@resource}"

      if source_path.include?('.zip')
        response = @@rest_client.multipart(signature, resource_url, query_params, body, source_path)
      else
        response = @@rest_client.post(signature, resource_url, query_params, body)
      end

    end

    def push_request(instance, framework, runtime, memory, domain, cdn_url)
      p 'In push request--------------------------------------!!'
      target = App42::Target.target_info['target'][:token]
      api_key, secrete_key = App42::Target.get_keys if target.eql? HOST
      body = {'app42' => {"app"=> {
          "instance" => instance,
          "framework" => framework,
          "runtime" => runtime,
          "memory" => memory,
          "domain" => domain,
          "cdn_url" => cdn_url
      }}}.to_json
      query_params, util = {}, Util.new
      params = {
          'api_key'=> api_key,
          'timeStamp' => util.get_timestamp_utc
      }
      query_params = params.clone
      params.store("body", body)
      puts params
      puts query_params
      signature = util.sign secrete_key, params
      resource_url = "#{@@resource}"
      response = @@rest_client.post(signature, resource_url, query_params, body)
    end

  end
end