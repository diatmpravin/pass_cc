require 'app42/version'
require 'app42/command/info'
require 'app42/command/user'
require 'app42/command/app'
require 'app42/base/help'
require 'paint'
require 'optparse'

module App42
  class Client

    attr_reader   :kclass
    attr_reader   :command
    attr_reader   :arg
    attr_reader   :options

    def initialize(arg = [])
      @arg = arg
      @options = {}
      @exit_status = true
    end

    #def Client.app42(*comm )
    #  new(comm).start
    #end
    #
    #def start
    #
    #  trap('TERM') { print "\nTerminated\n"; exit(false)}
    #
    #  parse_options!
    #
    #  raise 'shephertz'
    #end
    #
    #
    #def parse_options!
    #  opt_parser = OptionParser.new do |opt|
    #    opt.banner = "Usage: opt_parser COMMAND [OPTIONS]"
    #    opt.separator  ""
    #    opt.separator  "Commands"
    #    opt.separator  "     start: start server"
    #    opt.separator  "     stop: stop server"
    #    opt.separator  "     restart: restart server"
    #    opt.separator  ""
    #    opt.separator  "Options"
    #
    #    opt.on("-e","--environment ENVIRONMENT","which environment you want server run") do |environment|
    #      options[:environment] = environment
    #    end
    #
    #    opt.on("-d","--daemon","runing on daemon mode?") do
    #      options[:daemon] = true
    #    end
    #
    #    opt.on("-h","--help","help") do
    #      puts opt_parser
    #    end
    #  end
    #
    #end




    def self.app42(*arg )
      begin
        action = arg.shift.strip rescue 'help'
        App42::Client.new.start(action, arg)
      rescue Interrupt
        # TODO, fixum
        `stty icanon echo`
        puts Paint[" Command cancelled.", :red]
      rescue => error
        puts error
        exit(1)
      end

    end

    def parse_options!
      opts_parser = OptionParser.new do |opts|
        opts.banner = "\nAvailable options:\n\n"

        opts.on('--email EMAIL')     { |email| @options[:email] = email }
        opts.on('--user EMAIL')      { |email| @options[:email] = email }
        opts.on('--passwd PASS')     { |pass|  @options[:password] = pass }
        opts.on('--pass PASS')       { |pass|  @options[:password] = pass }
        opts.on('--password PASS')   { |pass|  @options[:password] = pass }
        opts.on('--token-file TOKEN_FILE')     { |token_file|  @options[:token_file] = token_file }
        opts.on('--app NAME')        { |name|  @options[:name] = name }
        opts.on('--name NAME')       { |name|  @options[:name] = name }
        opts.on('--bind BIND')       { |bind|  @options[:bind] = bind }
        opts.on('--instance INST')   { |inst|  @options[:instance] = inst }
        opts.on('--instances INST')  { |inst|  @options[:instances] = inst }
        opts.on('--url URL')         { |url|   @options[:url] = url }
        opts.on('--mem MEM')         { |mem|   @options[:mem] = mem }
        opts.on('--path PATH')       { |path|  @options[:path] = path }
        opts.on('--no-start')        {         @options[:nostart] = true }
        opts.on('--nostart')         {         @options[:nostart] = true }
        opts.on('--force')           {         @options[:force] = true }
        opts.on('--all')             {         @options[:all] = true }

        # generic tracing and debugging
        opts.on('-t [TKEY]')         { |tkey|  @options[:trace] = tkey || true }
        opts.on('--trace [TKEY]')    { |tkey|  @options[:trace] = tkey || true }

        # start application in debug mode
        opts.on('-d [MODE]')         { |mode|  @options[:debug] = mode || "run" }
        opts.on('--debug [MODE]')    { |mode|  @options[:debug] = mode || "run" }

        # override manifest file
        opts.on('-m FILE')           { |file|  @options[:manifest] = file }
        opts.on('--manifest FILE')   { |file|  @options[:manifest] = file }

        opts.on('-q', '--quiet')     {         @options[:quiet] = true }

        # micro cloud options
        opts.on('--vmx FILE')        { |file|  @options[:vmx] = file }
        opts.on('--vmrun FILE')      { |file|  @options[:vmrun] = file }
        opts.on('--save')            {         @options[:save] = true }

        # Don't use builtin zip
        opts.on('--no-zip')          {         @options[:nozip] = true }
        opts.on('--nozip')           {         @options[:nozip] = true }

        opts.on('--no-resources')    {         @options[:noresources] = true }
        opts.on('--noresources')     {         @options[:noresources] = true }

        opts.on('--no-color')        {         @options[:colorize] = false }
        opts.on('--verbose')         {         @options[:verbose] = true }

        opts.on('-n','--no-prompt')  {         @options[:noprompts] = true }
        opts.on('--noprompt')        {         @options[:noprompts] = true }
        opts.on('--non-interactive') {         @options[:noprompts] = true }

        opts.on('--prefix')          {         @options[:prefixlogs] = true }
        opts.on('--prefix-logs')     {         @options[:prefixlogs] = true }
        opts.on('--prefixlogs')      {         @options[:prefixlogs] = true }

        opts.on('--json')            {         @options[:json] = true }

        opts.on('-v', '--version')   {         set_cmd(:misc, :version) }
        opts.on('-h', '--help')      {         puts "#{command_usage}\n"; exit }

        opts.on('--port PORT')       { |port|  @options[:port] = port }

        opts.on('--runtime RUNTIME') { |rt|    @options[:runtime] = rt }

        # deprecated
        opts.on('--exec EXEC')       { |exec|  @options[:exec] = exec }
        opts.on('--noframework')     {         @options[:noframework] = true }
        opts.on('--canary')          {         @options[:canary] = true }

        # Proxying for another user, requires admin privileges
        opts.on('-u PROXY')          { |proxy| @options[:proxy] = proxy }

        # Select infrastructure
        opts.on('--infra INFRA')     { |infra| @options[:infra] = infra }

        opts.on_tail('--options')    {          puts "#{opts}\n"; exit }
      end
      self
    end

    def start(command, arg = [])
      if is_available?(command)
        parse_options!
        run command
        cmd = App42.const_get(@kclass.to_s.capitalize)
        cmd.new.send(@command)
      elsif command == 'help'
        send(command)
      else
        puts Paint["app42: Unknown command [#{command}]", :red]
        App42::Help.how_to
      end
    end


    def is_available? command
      App42::Shell::APP42_COMMAND.include?(command)
    end

    def run command
      case command
        when 'version'
          set_cmd(:version, :version)

        when 'list'
          set_cmd(:info, :list)

        when 'login'
          set_cmd(:user, :login)

        when 'logout'
          set_cmd(:user, :logout)

        when 'apps'
          set_cmd(:app, :apps)

        when 'deploy'
          set_cmd(:app, :deploy)

        else
        puts Paint["app42: Unknown command [#{action}]", :red]
        App42::Help.how_to
      end
    end

    def set_cmd(kclass, command)
      @kclass =  kclass
      @command=  command
    end

    def help
      App42::Help.commands
    end

  end
end