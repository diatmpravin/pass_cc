require 'app42/base/constants'
require 'fileutils'
require 'yaml'

module App42
  class Target
    class << self

      def ensure_config_dir
        FileUtils.mkdir_p(config_path) unless File.exist? config_path
      end

      def check_token_file
        info = YAML.load_file(token_path) if File.exist? token_path
        return true unless info.nil? || info['api_key'].nil? || info['secrete_key'].nil?
      end

      def target_info
        info = YAML.load_file(target_path) if File.exist? target_path
        info ||= {}
        normalize_targets_info(info)
      end

      def normalize_targets_info(info_by_url)
        info_by_url.reduce({}) do |hash, pair|
          key, value = pair
          hash[key] = value.is_a?(String) ? { :token => value } : value
          hash
        end
      end

      def get_keys
        keys = YAML.load_file(token_path) if File.exist? token_path
        return keys['api_key'], keys['secrete_key'] unless keys.empty?
      end

      def local_app42_target
        ensure_target_file

        File.open(target_path, "w") do |f|
          f.puts "target:"
          f.puts "  #{HOST}"
        end

      end

      def local_app42_token  api_key, secrete_key
        ensure_token_file

        File.open(token_path, "w") do |f|
          f.puts "api_key:"
          f.puts "  #{api_key}"
          f.puts "secrete_key:"
          f.puts "  #{secrete_key}"
        end
      end

      def remove_token_file
        FileUtils.rm_f(token_path)
      end

      def token_path
        File.expand_path(App42::TOKENS_FILE)
      end

      def config_path
        File.expand_path(App42::CONFIG_DIR)
      end

      def target_path
        File.expand_path(App42::TARGET_FILE)
      end

      def ensure_target_file
        FileUtils.mkdir_p(target_path) unless File.exist? target_path
      end

      def ensure_token_file
        FileUtils.mkdir_p(token_path) unless File.exist? token_path
      end


    end
  end
end