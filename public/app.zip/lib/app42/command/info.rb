require "app42/base/shell"
require "app42/version"


module App42
  class Info


    def version
      VERSION
    end

    def list
      puts Paint["All app42 available commands", :blue]
      App42::Shell::APP42_COMMAND.select { |action| puts Paint["app42 #{action}", :bright]}
    end


  end
end