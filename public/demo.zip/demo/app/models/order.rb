class Order < ActiveRecord::Base
  attr_accessible :name
end
