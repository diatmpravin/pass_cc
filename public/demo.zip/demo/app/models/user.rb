class User < ActiveRecord::Base
  attr_accessible :emailId, :pwd, :uName

  def initialize
    #Enter your Public Key and Private Key Here in Constructor. You can
	    #get it once you will create a app in app42 console
	    sp = App42RubyAPI::ServiceAPI.new("22a1b39e2472beedf2cd7ba57aa7d390f8422ed36631fd0e1956cf964cdd0d60","569607545e51fee42ee4d73a5c8de990b8a4c7fcc46a6e6eee5d2c13acbf1e8a")

	    #Create Instance of User Service
	    user_obj = sp.buildUserService()

	    p user_obj

	    #create user or call other available method on the user service
	    #reference
	    begin 
	        user = user_obj.create_user("pravinaa", "673899","pravinaa@shephertz.com");

    	    #Fetch the returned JSON response
	        puts" User Creation Successfull !!! JSON Response is : " + user.to_s;
	    rescue App42BadParameterException => ex
	        puts("App42BadParameterException ");
	    	# Exception Caught
	    	# Check if User already Exist by checking app error code
	    	if ex.app_error_code == 2001
	      		# Do exception Handling for Already created User.
	      		puts "User already exist with given user name";
	    	end 
	    rescue App42SecurityException => ex  
	    	puts("App42SecurityException ");
	    	# Exception Caught
	    	# Check for authorization Error due to invalid Public/Private Key
	    	if ex.app_error_code == 1401
	      		# Do exception Handling here
	    	end
	    rescue App42Exception =>ex  
	    	puts "App42Exception ";
	    	# Exception Caught due to other Validation
  	  	end
     
  end
end
