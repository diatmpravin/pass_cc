class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.string :uName
      t.string :pwd
      t.string :emailId

      t.timestamps
    end
  end
end
