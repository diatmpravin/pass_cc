# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Demo::Application.config.secret_token = '597c1f5b55ebea5e0496d48f5ac08aa71544ea51aff4d8a5e5e3419e8369951577a2348f9c61cea2fe0b0306bf98f7259771f849fe8683a15315dd63e2984a0f'
